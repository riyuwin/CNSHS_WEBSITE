<?php

include 'db_connection.php';

$conn = OpenCon();

if (isset($_GET['applicant_id'])){
    echo $_GET['applicant_id'];
}

?>