<?php

session_start();

include 'db_connection.php';

$conn = OpenCon();

if (isset($_POST['email']) && isset($_POST['password'])) {
    function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    $email = validate($_POST['email']);
    $pass = validate($_POST['password']); 
    
    if (empty($email)) {
        header("Location: ../login_form.php?error=Username is required.");
        exit();
    }else if (empty($pass)) { 
        header("Location: ../login_form.php?error=Password is required.");
        exit();

    } else {
        $sql = "SELECT * FROM user_registration WHERE email='$email' AND password='$pass' ";

        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) === 1) {
            echo "Hello";
            $row = mysqli_fetch_assoc($result);

            if ($row['email'] === $email && $row['password'] === $pass) {
                echo "Logged in!";

                $_SESSION['fname'] = $row['fname'];
                $_SESSION['mname'] = $row['mname'];
                $_SESSION['lname'] = $row['lname'];
                $_SESSION['email'] = $row['email'];
                $_SESSION['user_id'] = $row['user_id'];

                print_r($row);
                header("Location: ../admission.php");
                exit();
            } else{ 

                echo "Incorrect username or password.";
                header("Location: ../login_form.php?error=Incorrect username or password.");
                exit();
            }
        } else {
            header("Location: ../login_form.php?error=Incorrect username or password.");
            exit();
        }
    }

} else {
    header("Location: ../login_form.php?error");
    exit();
}


CloseCon($conn);

?>